#include "caffe/layers/parameter_layer.hpp"

namespace caffe {

INSTANTIATE_CLASS(ParameterLayer);
REGISTER_LAYER_CLASS(Parameter);

}  // namespace caffe
